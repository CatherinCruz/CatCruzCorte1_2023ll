def inventario(lista):
    lista:[carbon,madera,madera,diamante,diamante,diamante]
    carbon=lista
    madera=lista
    diamante=lista

def main():
    





    if __name__=='__main__':
        main()